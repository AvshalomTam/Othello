#include "../include/Menu.h"

game_type Menu::getGameType() {
  return this->type_;
}